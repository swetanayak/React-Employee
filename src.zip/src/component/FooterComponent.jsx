import React,{ Component } from  'react'


class FooterComponent extends Component{
    constructor(props){
        super(props)
        this.state={

        }
    }
    render() {
        return(
            <>
    <footer class="bg-dark text-center text-white">
     <div class="container p-4">
     {/* Section: Social media  */}
    <section class="mb-4">
      <a>
        <span style={{"color":"#00acee"}}><i class="fab fa-twitter"></i></span>
        <span style={{"color":"#405DE6"}}><i class="fab fa-instagram"></i></span>
        
        <span style={{"color":"#86888a"}}><i class="fab fa-linkedin"></i></span>
        <span style={{"color":"#3b5998"}}><i class="fab fa-facebook"></i></span>
      
       </a>
    </section>
   
   {/* Section: Form  */}
    <section class="">
      <form action="">
        {/* Grid row starts */}
        <div class="row d-flex justify-content-center">
          {/* Grid column */}
          <div class="col-auto">
            <p class="pt-2">
              <strong>Sign up for our newsletter</strong>
            </p>
          </div>
          {/* Grid column ends */}

          {/* Grid column starts */}
          <div class="col-md-5 col-12">
            {/* Email input  */}
            <div class="form-outline form-white mb-4">
              <input type="email" id="name" class="form-control" placeholder="Email Address"/>
          
            </div>
        </div>

          {/* Grid column ends */}

          {/* Grid column starts */}
          <div class="col-auto">
             {/* Submit button named as Suscribe */}
            <button type="submit" class="btn btn-outline-light mb-4">
              Subscribe
            </button>
          </div>
         {/* Grid column ends */}
        </div>
       {/* Grid row ends -started in line-43 */}
      </form>
    </section>
    {/* Section: Form  ends here */}
    {/* Section: about Project> */}
    <section class="mb-4">
      <p>
       Employee Management System is structured to monitor,assess and control the employee information
       and to efficiently utilize the human resources.MoreoverA flexible and easy to use Employee 
       Management software solution for small and medium sizedcompanies
      </p>
    </section>
   {/* Section: Text about project ends */}

     {/* Section: Links  */}
    <section class="">
     
      <div class="row">
       
        <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase">EMS</h5>

          <ul class="list-unstyled mb-0">
            <li>
              <a href="#!" class="text-white">Link 1</a>
            </li>
            <li>
              <a href="#!" class="text-white">Link 2</a>
            </li>
            <li>
              <a href="#!" class="text-white">Link 3</a>
            </li>
            <li>
              <a href="#!" class="text-white">Link 4</a>
            </li>
          </ul>
        </div>
       
        <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase">ABOUT US</h5>

          <ul class="list-unstyled mb-0">
            <li>
              <a href="#!" class="text-white">Link 1</a>
            </li>
            <li>
              <a href="#!" class="text-white">Link 2</a>
            </li>
            <li>
              <a href="#!" class="text-white">Link 3</a>
            </li>
            <li>
              <a href="#!" class="text-white">Link 4</a>
            </li>
          </ul>
        </div>
       
        <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase">CONTACT US</h5>

          <ul class="list-unstyled mb-0">
            <li>
              <a href="#!" class="text-white">Link 1</a>
            </li>
            <li>
              <a href="#!" class="text-white">Link 2</a>
            </li>
            <li>
              <a href="#!" class="text-white">Link 3</a>
            </li>
            <li>
              <a href="#!" class="text-white">Link 4</a>
            </li>
          </ul>
        </div>
        
        <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase">SUPPORT</h5>

          <ul class="list-unstyled mb-0">
            <li>
              <a href="#!" class="text-white">Link 1</a>
            </li>
            <li>
              <a href="#!" class="text-white">Link 2</a>
            </li>
            <li>
              <a href="#!" class="text-white">Link 3</a>
            </li>
            <li>
              <a href="#!" class="text-white">Link 4</a>
            </li>
          </ul>
        </div>
       
      </div>
      
    </section>
    {/* Section: Links ends here */}
  </div>
  {/* Grid container  */}
</footer>

  

            

            </>
        )
    }
}

export default FooterComponent;