import React,{Component} from "react";

class  AddEmployeeComponent extends Component{
    constructor(props){
        super(props)
        this.state={}
    }
    render(){
        return(
            <>
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-12">
                        <form>
                        <div className='row mt-3'>
                            <div className='col-md-6 mx-auto mt-5 card mb-5'>
                                <div className='form-group'>
                                    <label>Employee Name</label>
                                    <input type="text" className='form-control' name="employeeName" value={this.state.employeeName} onChange={this.employeeNameHandler}></input>
                                </div>

                                <div className='form-group'>
                                    <label>Father Name</label>
                                    <input type="number" className='form-control' name="fatherName" value={this.state.fatherName} onChange={this.fatherNameHandler}></input>
                                </div>

                                <div className='form-group'>
                                    <label>Age</label>
                                    <input type="number" className='form-control' name="age" value={this.state.age} onChange={this.ageHandler}></input>
                                </div>

                                <div className='form-group'>
                                    <label>Mobile No</label>
                                    <input type="url" className='form-control' name="mobileNo" value={this.state.mobileNo} onChange={this.mobileNoHandler}></input>
                                </div>

                                <div className='form-group'>
                                    <label>Adhar No</label>
                                    <input type="text" className='form-control' name="adharNo" value={this.state.adharNo} onChange={this.adharNoHandler}></input>
                                </div>
                                
                               
                                

                            <button className='btn btn-outline-success mb-5' onClick={this.addProduct}>Add Product</button>

                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
            </>
        )
    }
}