import React, {Component} from "react";

class AppraisalComponent extends Component{
    constructor(props) {
        super(props)
        this.state = {

        }
}
 render(){
     return(
         <>
         
         </>
     )
 }

     

}