import React, { Component } from "react";

class AllEmployeeComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {}
    }

    render() {
        return (
            <>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-2">
                            <table>
                                <tr>
                                    <th>EMP ID</th>
                                    <th>Emp Name</th>
                                    <th>Office Loc</th>
                                    <th>Designation</th>
                                    <th>Domain</th>
                                    <th>Status</th>
                                </tr>
                                <tr>
                                    <td>1012</td>
                                    <td>Manish</td>
                                    <td>Noida</td>
                                    <td>PA</td>
                                    <td>Java Fse</td>
                                    <td>active</td>
                                </tr>
                            </table>

                        </div>
                    </div>
                </div>

            </>
        )
    }
}