import React, { Component } from 'react'
import { withRouter, Link } from 'react-router-dom';

class HeaderComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {

        }
    }
        render() {
            const details = JSON.parse(localStorage.getItem('detail'));
            const adminDetails = JSON.parse(localStorage.getItem('adminDetail'));
            if(details){
            return (
                <>
                    <div className="App">
                        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                            <a class="navbar-brand" href="#">EMS</a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <ul class="navbar-nav mr-auto">
                                    <li class="nav-item active">
                                        <a class="nav-link" href="#">HOME <span class="sr-only">(current)</span></a>
                                    </li>
                                    <li class="nav-item">
                                                <Link class="nav-link" to="/about">About</Link>
                                            </li>
                                    
                                            <li class="nav-item">
                                                <Link class="nav-link" to="/contact">Contact</Link>
                                            </li>
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Dropdown
                                        </a>
                                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                            <a class="dropdown-item" href="#">Action</a>
                                            <a class="dropdown-item" href="#">Another action</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Something else here</a>
                                        </div>
                                    </li>
                                    <ul class="navbar-nav mr-5">

                                            <li class="nav-item dropdown">
                                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    Login/Register
                                                </a>
                                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                    <Link class="dropdown-item" to="/user-login">User</Link>
                                                    <div class="dropdown-divider"></div>
                                                    <Link class="dropdown-item" to="/admin-login">Admin</Link>
                                                </div>
                                            </li>
                                            <li className='nav-item'>
                                                <Link className='nav-link' to='/feedback-detail'>User Feedback</Link>
                                            </li>

                                        </ul>
                                </ul>


                            </div>
                        </nav>
                    </div>
                </>
            )
        }
        if (adminDetails) {
            return (
                <>
                <div className="App">
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                    <a class="navbar-brand" href="#">EMS</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item active">
                                <a class="nav-link" href="#">HOME <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item">
                                        <Link class="nav-link" to="/allemp">All Employee</Link>
                                    </li>
                            
                                    <li class="nav-item">
                                        <Link class="nav-link" to="/addemp">Add Employee</Link>
                                    </li>
                                    <li class="nav-item">
                                        <Link class="nav-link" to="/updateemp">Update Employee</Link>
                                    </li>
                                    <li class="nav-item">
                                        <Link class="nav-link" to="/appraisal">Appraisal</Link>

                                    </li>
                                    <li class="nav-item">
                                        <Link class="nav-link" to="/anniversary">Anniversary</Link>
                                    </li>
                                    
                                    
                                    
                           
                            <ul class="navbar-nav mr-5">

                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Logout
                                        </a>
                                        
                                    </li>
                                    <li className='nav-item'>
                                        <Link className='nav-link' to='/feedback-detail'>Feedback</Link>
                                    </li>

                                </ul>
                        </ul>


                    </div>
                </nav>
            </div>
        </>
            )
        }
        else {
            return(
                <>
                <div className="App">
                        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                            <a class="navbar-brand" href="#">EMS</a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <ul class="navbar-nav mr-auto">
                                    <li class="nav-item active">
                                        <a class="nav-link" href="#">HOME <span class="sr-only">(current)</span></a>
                                    </li>
                                    <li class="nav-item">
                                                <Link class="nav-link" to="/about">About</Link>
                                            </li>
                                    
                                            <li class="nav-item">
                                                <Link class="nav-link" to="/contact">Contact</Link>
                                            </li>
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Dropdown
                                        </a>
                                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                            <a class="dropdown-item" href="#">Action</a>
                                            <a class="dropdown-item" href="#">Another action</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Something else here</a>
                                        </div>
                                    </li>
                                    <ul class="navbar-nav mr-5">

                                            <li class="nav-item dropdown">
                                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    Login/Register
                                                </a>
                                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                    <Link class="dropdown-item" to="/user-login">User</Link>
                                                    <div class="dropdown-divider"></div>
                                                    <Link class="dropdown-item" to="/admin-login">Admin</Link>
                                                </div>
                                            </li>
                                            <li className='nav-item'>
                                                <Link className='nav-link' to='/feedback-detail'>User Feedback</Link>
                                            </li>

                                        </ul>
                                </ul>


                            </div>
                        </nav>
                    </div>
                </>
            )
        }

      
    }
}

export default withRouter(HeaderComponent);