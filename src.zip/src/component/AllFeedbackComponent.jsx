import React,{ Component } from "react";

class AllFeedbackComponent extends Component{
    constructor(props){
        super(props)
        this.state={}
    }
    render(){
        return(
            <>
            <div className="container">
                <div className="row-mt-5">
                    <div className="col-md-12 mt-5 card mb-3">
                        <table className="table table-bordered table-light mt-3">
                            <thead>
                                <tr>
                                <th>MangerName</th>
                                <th>EmployeeName</th>
                                <th>FeedBack</th>
                                </tr>
                            </thead>
                           

                        </table>
                    </div>

                </div>
            </div>
            </>
        )
    }
}
export default AllFeedbackComponent;