import React,{ Component } from 'react';
import { withRouter, Link } from 'react-router-dom';
import login1 from '../image/login1.jpg'

class LoginComponent extends Component{
    constructor(props){
        super(props)
        this.state={}
    }
    render(){
        return(
            <>
             <div className='container-fluid' style={{ marginTop: "56px" }}>
                    <div className='row'>
                        <div className='col-md-6 card p-0'>
                            <img src={login1} style={{ width: "100%", height: "300px" }}></img>
                        </div>

                        <div className='col-md-6 card'>
                            <form>
                                <div className='from-group'>
                                    <label>Username</label>
                                    <input type="text" placeholder='Enter Username' name="userName" required className='form-control' onChange={this.usernameHandler} value={this.state.userName} />
                                </div>
                                <div className='from-group'>
                                    <label>Password</label>
                                    <input type="password" placeholder='Enter Password' name="userPassword" required className='form-control' onChange={this.passwordHandler} value={this.state.userPassword}></input>
                                </div>
                               
                                <div>
                                    
                                    <button type="button" className='btn btn-success mt-3 mr-5' onClick={this.login}>Submit</button>


                                    <Link className='btn btn-primary mt-3' to="/user-signup">Create a account</Link>

                                </div>

                            </form>

                        </div>
                    </div>

                </div>

            </>
        )
    }
}
export default withRouter(LoginComponent);