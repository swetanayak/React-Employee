import React,{ Component } from "react";
import { withRouter, Link } from 'react-router-dom';
import signup from '../image/signup.jpg'

class SignupComponent extends Component{
    constructor(props){
        super(props)
        this.state={}
    }

render(){
    return(
        <>
<div className='container-fluid' style={{ marginTop: "55px" }}>
                    <div className='row'>
                        <div className='col-md-6 p-0'>
                            <img src={signup} style={{ width: "100%", height: "535px" }}></img>

                        </div>
                        <div className='col-md-6 card p-3'>
                            <form>
                                <div className='row'>
                                    <div className='col-md-6'>
                                        <div className='form-group'>
                                            <label>First Name</label>
                                            <input type="text" className='form-control' name="userFirstName" required placeholder='Enter First Name' onChange={this.changeUserFirstNameHandler} value={this.state.userFirstName}></input>
                                        </div>
                                    </div>
                                    <div className='col-md-6'>
                                        <label>Last Name</label>
                                        <input type="text" className='form-control' name="userLastName" required placeholder='Enter Last Name' onChange={this.changeUserLastNameHandler} value={this.state.userLastName}></input>
                                    </div>
                                </div>
                                <div className='row'>
                                    <div className='col-md-6'>
                                        <div className='form-group'>
                                            <label>Username</label>
                                            <input type="text" className='form-control' name="userName" required placeholder='Enter Username' onChange={this.changeUserNameHandler} value={this.state.userName}></input>
                                        </div>
                                    </div>
                                    <div className='col-md-6'>
                                        <div className='form-group'>
                                            <label>Email</label>
                                            <input type="email" className='form-control' name="userEmail" required placeholder='Enter Email Id' onChange={this.changeUserEmailHandler} value={this.state.userEmail}></input>
                                        </div>
                                    </div>
                                </div>
                                <div className='row'>
                                    <div className='col-md-6'>
                                        <div className='form-group'>
                                            <label>Password</label>
                                            <input type="password" className='form-control' name="userPassword" required placeholder='Enter Password' onChange={this.changeUserPasswordHandler} value={this.state.userPassword}></input>
                                        </div>
                                    </div>
                                    <div className='col-md-6'>
                                        <div className='form-group'>
                                            <label>Contact</label>
                                            <input type="tel" className='form-control' name="userContact" required placeholder='Enter Contact Number' onChange={this.changeUserContactHandler} value={this.state.userContact}></input>
                                        </div>
                                    </div>
                                </div>
                                <div className='row'>
                                    <div className='col-md-6'>
                                        <div className='form-group'>
                                            <label>Pincode</label>
                                            <input type="number" className='form-control' name="userPincode" required placeholder='Enter Pincode Number' onChange={this.changeUserPincodeHandler} value={this.state.userPincode}></input>
                                        </div>
                                    </div>
                                    <div onChange={this.onChangeValue} className='col-md-6'>
                                        <label>Gender</label><br></br>
                                        <input type="radio" value="Male" name="userGender" /> <label className='mr-3'>Male</label>
                                        <input type="radio" value="Female" name="userGender" /> Female
                                    </div>
                                </div>
                                <div className='form-group'>
                                    <label>Address</label>
                                    <textarea className='form-control' name="userAddress" required onChange={this.changeUserAddressHandler} value={this.state.userAddress}>Address</textarea>
                                </div>

                                <button type="submit" className='btn btn-success mb-2' onClick={this.register}>Submit</button>

                            </form>
                        </div>
                    </div>

                </div >
        </>
    )
}
}
export default withRouter(SignupComponent);