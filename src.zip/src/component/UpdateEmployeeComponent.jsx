import React,{ Component } from "react";

class UpdateEmployeeComponent extends Component{
    constructor(props){
        super(props)
        this.state={}
    }
    render(){
        return(
            <>
                    <div className="container">
                        <div className="row mt-5">
                            {this.state.product.map(data =>
                                <div className="col-md-4 mt-5 mb-2">
                                    <div className="card">
                                        <img className="card-img-top" src={data.empPic} alt="Card image cap" style={{ height: "200px" }} />
                                        <div className="card-body">
                                            <h5 className="card-title text-center aria-readonly">{data.empName}</h5>
                                            <hr></hr>
                                            <h6>Office Loc  :  <del><span>&#8377;{data.officeLoc}</span></del></h6>
                                            <hr></hr>
                                            <h6>Designation  :  <span>&#8377;{data.designation}</span></h6>
                                            <hr></hr>
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                            )
                            }
                        </div>
                    </div>
            

            </>
        )
    }
}