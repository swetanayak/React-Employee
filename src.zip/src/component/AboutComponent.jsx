import React, { Component } from "react"
import aboutslide1 from '../image/aboutslide1.jpg'
import aboutslide2 from '../image/aboutslide2.jpg'
import aboutslide3 from '../image/aboutslide3.jpg'





class AboutComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {}
    }
    render() {
        return (
            <>
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img class="d-block w-100" src={aboutslide1} alt="First slide"></img>
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src={aboutslide2} alt="Second slide"></img>
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src={aboutslide3} alt="Third slide"></img>
                        </div>
                    </div>

                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>

                <div class="col-md-12 p-0">
                    <h5 class="bg-dark text-light text-center" ><marquee direction="right">Self REGISTRATION now available on EMPLOYEE MANAGEMENT SYSTEM. A few days ago, we gave our Employees hike of 10 percent, and our services are currently present in 20 Companies.</marquee> </h5>
                </div>
                <div class="col-md-12 p-0">
                    <h5 class="bg-dark text-light text-center" ><marquee direction="left">Get Register with your company today, And get many offers and discounts on exclusive services.</marquee> </h5>
                </div>

                {/* cards */}
               
                <div class="card-group">
  <div class="card">
   
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
  <div class="card">
  
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
  <div class="card">
   
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
</div>
            </>
        )
    }
}
export default AboutComponent;