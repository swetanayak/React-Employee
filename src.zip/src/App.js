
import './App.css';
import { BrowserRouter, Route, Switch } from 'react-router-dom';

import React, { Component } from 'react';
import HeaderComponent from './component/HeaderComponent';
import FooterComponent from './component/FooterComponent';
import HomeComponent from './component/HomeComponent';
import AboutComponent from './component/AboutComponent';
import ContactComponent from './component/ContactComponent';
import LoginComponent from './component/LoginComponent';
import SignupComponent from './component/SignupComponent';
import AllFeedbackComponent from './component/AllFeedbackComponent';
import AdminLoginComponent from './component/AdminLoginComponent';

class App extends Component {
  constructor(props) {
    super(props)
    this.state = {}
  }
  render() {
    return (
      <div>
        <BrowserRouter>
          <HeaderComponent></HeaderComponent>
          <Switch>

            <Route path="/" exact component={HomeComponent} />
            <Route path="/about" component={AboutComponent}></Route>
            <Route path="/contact" component={ContactComponent}></Route>
            <Route path="/user-login" component={LoginComponent}></Route>
            <Route path="/user-signup" component={SignupComponent}></Route>
            <Route path="/feedback-detail" component={AllFeedbackComponent}></Route>
            <Route path="/admin-login" component={AdminLoginComponent}></Route>

          </Switch>
          <FooterComponent />
        </BrowserRouter>
      </div>

    )
  }
}



export default App;
